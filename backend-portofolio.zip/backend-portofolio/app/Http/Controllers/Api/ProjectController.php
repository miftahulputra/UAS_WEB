<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ProjectController extends Controller
{
    public function get()
    {
        $data = Project::all();
        return response([
            'total' => $data->count(),
            'messages' => 'Retrieved successfuly',
            'data' => $data
        ], 200);
    }

    public function store(Request $request)
    {
        //define validation rules
        $validator = Validator::make($request->all(), [
            'image'     => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'title'     => 'required',
            'description'   => 'required',
        ]);

        //check if validation fails
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        //upload image
        $image = $request->file('image');
        $image->storeAs('public/posts', $image->hashName());

        //create post
        $data = Project::create([
            'image'     => $image->hashName(),
            'title'     => $request->title,
            'description'   => $request->description,
        ]);


        return response([
            'message' => 'Successfuly created',
            'data' => $data
        ], 201);
    }

    public function delete($id)
    {
        $data = Project::find($id);

        if ($data != null) {
            $data->delete();
            // Delete old image
            File::delete(public_path('storage/posts/' . $data->image));

            return response([
                'message' => 'Order has been deleted!'
            ]);
        } else {
            return response([
                'message' => 'No data found!',
            ], 404);
        }
    }
}
